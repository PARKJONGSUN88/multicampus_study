package lab.project.nlptest;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public final class MyUtil {
	public static final String dataPath = "D:\\dev\\workspace_prj2\\data\\";
	
	public static void WriteOuput(ArrayList<String> strList, String suf, String filename) {
		FileOutputStream fileOutputStream = null;
		OutputStreamWriter outputStreamWriter = null;
		BufferedWriter bufferedWriter = null;;
		try {
			fileOutputStream = new FileOutputStream(
					dataPath + "output\\" + suf +  filename);
			outputStreamWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
			bufferedWriter = new BufferedWriter(outputStreamWriter);
			
			int len1 = strList.size();
			for(int i = 0; i < len1 ; i++) {
				String arrStr[] = strList.get(i).split("\n");
				
				int len2 = arrStr.length;
				for(int j = 0; j < len2; j++) {
					bufferedWriter.write(arrStr[j] + "\r\n");
				}
			}
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(bufferedWriter != null) {
					bufferedWriter.flush();
					bufferedWriter.close();
				}
				if(outputStreamWriter != null) outputStreamWriter.close();
				if(fileOutputStream != null) fileOutputStream.close();

			} catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
}
