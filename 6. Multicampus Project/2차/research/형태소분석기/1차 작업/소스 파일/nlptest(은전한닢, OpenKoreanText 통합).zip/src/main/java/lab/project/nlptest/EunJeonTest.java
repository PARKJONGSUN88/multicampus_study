package lab.project.nlptest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import kr.bydelta.koala.data.Sentence;
import kr.bydelta.koala.eunjeon.Tagger;
import scala.collection.Iterator;
import scala.collection.Seq;

/*
 * #### Notice ####
 * MyUtil.java 파일에서 datPath를 설정한 뒤 사용
 */
public class EunJeonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("EunJeon Test!");

		// 또는 eunjeon 대신 다른 분석기 가능: arirang, daon, etri, eunjeon, hnn, kkma, kmr, okt, rhino 

		Tagger tagger = new Tagger();
		// 코모란 분석기는 경량 분석기를 사용하는 옵션이 있습니다. 예: new Tagger(true)
		// ETRI 분석기의 경우 API 키를 필수적으로 전달해야 합니다. 예: new Tagger(API_KEY)

		BufferedReader bReader = null;
		ArrayList<String> strList = new ArrayList<String>();
		
		String filename = "1.txt"; //파일명. 경로는 MyUtil 에 설정
		try {
			String s;
			File file = new File(MyUtil.dataPath + filename);
			bReader = new BufferedReader(new FileReader(file));
			
			while((s = bReader.readLine()) != null) {
				Seq<Sentence> taggedParagraph = tagger.tag(s);
				// 또는 tagger.invoke(...)
			
				Iterator<Sentence> iterator = taggedParagraph.iterator();
				
				while (iterator.hasNext()) {
					Sentence elem = (Sentence)iterator.next();
					strList.add(new String(elem.toString()));
				}
			}
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(bReader != null) bReader.close();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		//결과 출력
		MyUtil.WriteOuput(strList, "eunjeon_", filename);
		System.out.println("Done.");
		
	}
	
	
}