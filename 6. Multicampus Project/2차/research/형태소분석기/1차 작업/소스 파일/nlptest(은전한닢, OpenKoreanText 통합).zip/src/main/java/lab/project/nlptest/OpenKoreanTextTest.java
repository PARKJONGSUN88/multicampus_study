package lab.project.nlptest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openkoreantext.processor.OpenKoreanTextProcessorJava;
import org.openkoreantext.processor.phrase_extractor.KoreanPhraseExtractor;
import org.openkoreantext.processor.tokenizer.KoreanTokenizer;

import scala.collection.Seq;

/*
 * #### Notice ####
 * MyUtil.java 파일에서 datPath를 설정한 뒤 사용
 */
public class OpenKoreanTextTest {
  public static void main(String[] args) {
    
    
    BufferedReader bReader = null;
	ArrayList<String> strList = new ArrayList<String>();
	
	String filename = "1.txt"; //파일명. 경로는 MyUtil 에 설정
	try {
		String s;
		File file = new File(MyUtil.dataPath + filename);
		bReader = new BufferedReader(new FileReader(file));
		
		while((s = bReader.readLine()) != null) {
			CharSequence normalized = OpenKoreanTextProcessorJava.normalize(s);
			Seq<KoreanTokenizer.KoreanToken> tokens = OpenKoreanTextProcessorJava.tokenize(normalized);

			//ex) String text = "한국어를 처리하는 예시입니닼ㅋㅋㅋㅋㅋ #한국어";
			strList.add(OpenKoreanTextProcessorJava.tokensToJavaStringList(tokens).toString());
			// [한국어, 를, 처리, 하는, 예시, 입니, 다, ㅋㅋ, #한국어]
			
			strList.add((OpenKoreanTextProcessorJava.tokensToJavaKoreanTokenList(tokens).toString()));
		    // [한국어(Noun: 0, 3), 를(Josa: 3, 1), 처리(Noun: 5, 2), 하는(Verb(하다): 7, 2), 예시(Noun: 10, 2),
		    // 입니다(Adjective(이다): 12, 3), ㅋㅋㅋ(KoreanParticle: 15, 3), #한국어(Hashtag: 19, 4)]

		    // Phrase extraction
		    List<KoreanPhraseExtractor.KoreanPhrase> phrases = OpenKoreanTextProcessorJava.extractPhrases(tokens, true, true);
		    strList.add(phrases.toString());
		    // [한국어(Noun: 0, 3), 처리(Noun: 5, 2), 처리하는 예시(Noun: 5, 7), 예시(Noun: 10, 2), #한국어(Hashtag: 18, 4)]
		}
		
	} catch(IOException e) {
		e.printStackTrace();
	} finally {
		try {
			if(bReader != null) bReader.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	MyUtil.WriteOuput(strList, "OpenKoreanText_", filename);
	System.out.println("Done.");
  
  }
}
